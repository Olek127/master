package com.comprathor.comprathor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComprathorApplicationTests {

	@Test
	void contextLoads() {
	}

}
