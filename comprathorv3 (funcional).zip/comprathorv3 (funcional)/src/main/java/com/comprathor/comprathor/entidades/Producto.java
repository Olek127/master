package com.comprathor.comprathor.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_Producto")
    private Integer IDProducto;
    @ManyToOne
    @JoinColumn(name = "ID_Metadato", nullable = false)
    private Metadatos IDMetadato;
    @ManyToOne
    @JoinColumn(name = "ID_Usuario", nullable = false)
    private Usuario IDUsuario;
    private String Nombre;
    private String Descripcion;
    private String Fabricante;
    private BigDecimal Precio;
    private BigDecimal Valoracion;
    private String Imagen;

    public Producto(Integer idProductos) {
        this.IDProducto = idProductos;
    }
}
