package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.entidades.Usuario;

import java.util.List;
import java.util.Optional;

public interface UsuarioService {
    Usuario registrarUsuario(Usuario usuario);
    Optional<Usuario> obtenerUsuarioPorId(Integer id);
    List<Usuario> obtenerUsuarios();
    Usuario actualizarUsuario(Integer id, Usuario usuario);
    void eliminarUsuario(Integer id);

}
