package com.comprathor.comprathor.entidades;

public enum TipoDato {
    Texto,
    Número,
    Fecha
}
