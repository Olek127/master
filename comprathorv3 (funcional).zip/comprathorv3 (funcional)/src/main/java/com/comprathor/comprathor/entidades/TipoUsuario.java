package com.comprathor.comprathor.entidades;

public enum TipoUsuario {
    Regular,
    Administrador
}

