package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Comparativa;
import com.comprathor.comprathor.entidades.Producto;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;
import java.util.Optional;

public interface ComparativaService {
    Comparativa crearComparativa(Comparativa comparativa);
    Optional<Comparativa> obtenerComparativaPorId(Integer id);
    List<Comparativa> obtenerComparativas();
    List<Comparativa> obtenerComparativasPorUsuario(Integer idUsuario);
    int obtenerMaxComparativaUsuarioProducto(Integer idUsuario);
    Comparativa actualizarComparativa(Integer id, Comparativa comparativa);
    void eliminarComparativa(Integer id);
}
