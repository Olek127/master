package com.comprathor.comprathor.repositorio;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MetadatosRepository extends JpaRepository<Metadatos, Integer> {
    List<Metadatos> findByIDCategoria_IDCategoria(Integer idCategoria);
}
