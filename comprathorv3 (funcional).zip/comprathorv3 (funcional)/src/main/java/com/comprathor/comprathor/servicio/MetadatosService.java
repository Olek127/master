package com.comprathor.comprathor.servicio;


import com.comprathor.comprathor.entidades.Metadatos;

import java.util.List;
import java.util.Optional;

public interface MetadatosService {
    Metadatos crearMetadato(Metadatos metadato);
    Optional<Metadatos> obtenerMetadatoPorId(Integer id);
    List<Metadatos> obtenerMetadatos();
    List<Metadatos> obtenerMetadatosPorCategoria(Integer id);
    Metadatos actualizarMetadato(Integer id, Metadatos metadato);
    void eliminarMetadato(Integer id);
}
