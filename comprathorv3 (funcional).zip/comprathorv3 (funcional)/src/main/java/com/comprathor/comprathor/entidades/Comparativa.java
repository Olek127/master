package com.comprathor.comprathor.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Comparativa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_Comparativa")
    private Integer IDComparativa;

    //@Column(name = "ID_Usuario")
    @ManyToOne
    @JoinColumn(name = "ID_Usuario", nullable = false)
    private Usuario IDUsuario;

    private Integer ComparativaUsuarioProducto;

    @ManyToOne
    @JoinColumn(name = "ID_Producto", nullable = false)
    private Producto IDProducto;

    @Column(name = "Fecha_Creacion")
    private LocalDateTime FechaCreacion;

    private String Titulo;

    private String Descripcion;

    private BigDecimal Valoracion;

    public Comparativa(Integer idComparativas) {
        this.IDComparativa = idComparativas;
    }
}
