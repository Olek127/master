package com.comprathor.comprathor.controlador;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.repositorio.MetadatosRepository;
import com.comprathor.comprathor.servicio.CategoriaService;
import com.comprathor.comprathor.servicio.MetadatosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/metadatos", produces = "application/json")
@CrossOrigin(origins = "http://localhost:3000")
public class MetadatosController{

    @Autowired
    private MetadatosService metadatosService;

    @PostMapping(consumes = "application/json")
    public ResponseEntity<Metadatos> crearMetadato(@RequestBody Metadatos metadatos) {
        Metadatos metadatosnuevo = metadatosService.crearMetadato(metadatos);
        return new ResponseEntity<>(metadatosnuevo, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Metadatos> obtenerMetadatoPorId(@PathVariable Integer id) {
        return metadatosService.obtenerMetadatoPorId(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
    @GetMapping
    public ResponseEntity<List<Metadatos>> obtenerMetadatos() {
        List<Metadatos> metadatos = metadatosService.obtenerMetadatos();
        return new ResponseEntity<>(metadatos, HttpStatus.OK);
    }

    @GetMapping("/categoria/{id}")
    public ResponseEntity<List<Metadatos>> obtenerMetadatosPorCategoria(@PathVariable Integer id) {
        List<Metadatos> metadatos = metadatosService.obtenerMetadatosPorCategoria(id);
        return new ResponseEntity<>(metadatos, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Metadatos> actualizarMetadato(@PathVariable Integer id, @RequestBody Metadatos metadatos) {
        Metadatos metadatoActualizado = metadatosService.actualizarMetadato(id, metadatos);
        return ResponseEntity.ok(metadatoActualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarMetadato(@PathVariable Integer id) {
        metadatosService.eliminarMetadato(id);
        return ResponseEntity.noContent().build();
    }



    }
