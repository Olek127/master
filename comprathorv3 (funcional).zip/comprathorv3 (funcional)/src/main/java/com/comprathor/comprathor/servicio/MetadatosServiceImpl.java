package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.repositorio.MetadatosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class MetadatosServiceImpl implements  MetadatosService{

    @Autowired
    private MetadatosRepository metadatosRepository;
    @Override
    public Metadatos crearMetadato(Metadatos metadato) {
        return metadatosRepository.save(metadato);
    }

    @Override
    public Optional<Metadatos> obtenerMetadatoPorId(Integer id) {
        return metadatosRepository.findById(id);
    }

    @Override
    public List<Metadatos> obtenerMetadatos() {
        return metadatosRepository.findAll();
    }

    @Override
    public List<Metadatos> obtenerMetadatosPorCategoria(Integer id) {
        return metadatosRepository.findByIDCategoria_IDCategoria(id);
    }

    @Override
    public Metadatos actualizarMetadato(Integer id, Metadatos metadato) {
        if (metadatosRepository.existsById(id))
        {
            metadato.setIDMetadato(id);
            return metadatosRepository.save(metadato);
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }

    @Override
    public void eliminarMetadato(Integer id) {
        if (metadatosRepository.existsById(id))
        {
            metadatosRepository.deleteById(id);
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }
}
