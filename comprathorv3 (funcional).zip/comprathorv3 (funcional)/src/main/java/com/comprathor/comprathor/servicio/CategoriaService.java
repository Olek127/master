package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Categoria;
import com.comprathor.comprathor.entidades.Producto;

import java.util.List;
import java.util.Optional;

public interface CategoriaService {
    Categoria crearCategoria(Categoria categoria);
    Optional<Categoria> obtenerCategoriaPorId(Integer id);
    List<Categoria> obtenerCategorias();
    Categoria actualizarCategoria(Integer id, Categoria categoria);
    void eliminarCategoria(Integer id);
}
