package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.repositorio.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class ProductoServiceImpl implements ProductoService{

    @Autowired
    private ProductoRepository productoRepository;
    @Override
    public Producto crearProducto(Producto producto) {
        return productoRepository.save(producto);
    }

    @Override
    public Optional<Producto> obtenerProductoPorId(Integer id) {
        return productoRepository.findById(id);
    }

    @Override
    public List<Producto> obtenerProductos() {
        return productoRepository.findAll();
    }

    @Override
    public List<Producto> obtenerProductosPorMetadato(Integer id) {
        return productoRepository.findByIDMetadato_IDMetadato(id);
    }

    @Override
    public List<Producto> obtenerProductosPorUsuario(Integer id) {
        return productoRepository.findByIDUsuario_IDUsuario(id);
    }

    @Override
    public Producto actualizarProducto(Integer id, Producto producto) {
        if (productoRepository.existsById(id))
        {
            producto.setIDProducto(id);
            return productoRepository.save(producto);
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }

    @Override
    public void eliminarProducto(Integer id) {
        if (productoRepository.existsById(id))
        {
            productoRepository.deleteById(id);
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }
}
