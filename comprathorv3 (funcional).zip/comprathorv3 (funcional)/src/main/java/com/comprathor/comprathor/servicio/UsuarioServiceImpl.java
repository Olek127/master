package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Usuario;
import com.comprathor.comprathor.repositorio.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public Usuario registrarUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    @Override
    public Optional<Usuario> obtenerUsuarioPorId(Integer id) {
        return usuarioRepository.findById(id);
    }

    @Override
    public List<Usuario> obtenerUsuarios() {
        return usuarioRepository.findAll();
    }

    @Override
    public Usuario actualizarUsuario(Integer id, Usuario usuario) {
        if (usuarioRepository.existsById(id))
        {
            usuario.setIDUsuario(id);
            return usuarioRepository.save(usuario);
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }

    @Override
    public void eliminarUsuario(Integer id) {
        if (usuarioRepository.existsById(id))
        {
            usuarioRepository.deleteById(id);
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }

}
