package com.comprathor.comprathor.controlador;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.servicio.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/productos", produces = "application/json")
@CrossOrigin(origins = "http://localhost:3000")
public class ProductoController {
    @Autowired
    private ProductoService productoService;

    @PostMapping(consumes = "application/json")
    public ResponseEntity<Producto> crearProducto(@RequestBody Producto producto) {
        Producto productonuevo = productoService.crearProducto(producto);
        return new ResponseEntity<>(productonuevo, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Producto> obtenerProductoPorId(@PathVariable Integer id) {
        Optional<Producto> producto = productoService.obtenerProductoPorId(id);
        return producto.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<List<Producto>> obtenerProductos() {
        List<Producto> productos = productoService.obtenerProductos();
        return new ResponseEntity<>(productos, HttpStatus.OK);
    }

    @GetMapping("/metadatos/{id}")
    public ResponseEntity<List<Producto>> obtenerMetadatosPorCategoria(@PathVariable Integer id) {
        List<Producto> productos = productoService.obtenerProductosPorMetadato(id);
        return new ResponseEntity<>(productos, HttpStatus.OK);
    }

    @GetMapping("/usuario/{id}")
    public ResponseEntity<List<Producto>> obtenerMetadatosPorUsuario(@PathVariable Integer id) {
        List<Producto> productos = productoService.obtenerProductosPorUsuario(id);
        return new ResponseEntity<>(productos, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Producto> actualizarProducto(@PathVariable Integer id, @RequestBody Producto producto) {
        Producto productosActu = productoService.actualizarProducto(id, producto);
        return ResponseEntity.ok(productosActu);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<List<Producto>> eliminarProducto(@PathVariable Integer id) {
        productoService.eliminarProducto(id);
        return ResponseEntity.noContent().build();
    }


}
