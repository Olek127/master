package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Categoria;
import com.comprathor.comprathor.entidades.Comparativa;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.repositorio.ComparativaRepository;
import com.comprathor.comprathor.repositorio.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class ComparativaServiceImpl implements ComparativaService{
    @Autowired
    private ComparativaRepository comparativaRepository;
    @Autowired
    ProductoRepository productoRepository;
    @Override
    public Comparativa crearComparativa(Comparativa comparativa) {
        return comparativaRepository.save(comparativa);
    }

    @Override
    public Optional<Comparativa> obtenerComparativaPorId(Integer id) {
        return comparativaRepository.findById(id);
    }

    @Override
    public List<Comparativa> obtenerComparativas() {
        return comparativaRepository.findAll();
    }

    @Override
    public List<Comparativa> obtenerComparativasPorUsuario(Integer idUsuario) {
        return comparativaRepository.findByIDUsuario_IDUsuario(idUsuario);
    }

    @Override
    public int obtenerMaxComparativaUsuarioProducto(Integer idUsuario) {
        Integer maxComparativaUsuarioProducto = comparativaRepository.findMaxComparativaUsuarioProductoByUsuario(idUsuario);
        return maxComparativaUsuarioProducto != null ? maxComparativaUsuarioProducto : 1;
    }

    @Override
    public Comparativa actualizarComparativa(Integer id, Comparativa comparativa) {
        if (comparativaRepository.existsById(id))
        {
            comparativa.setIDComparativa(id);
            return comparativaRepository.save(comparativa);

        }
        else {
            throw new EntityNotFoundException("La comparativa con ID " + id + " no existe");
        }
    }

    @Override
    public void eliminarComparativa(Integer id) {
        if (comparativaRepository.existsById(id))
        {
            comparativaRepository.deleteById(id);
        }
        else {
            throw new EntityNotFoundException("La comparativa con ID " + id + " no existe");
        }
    }
}
