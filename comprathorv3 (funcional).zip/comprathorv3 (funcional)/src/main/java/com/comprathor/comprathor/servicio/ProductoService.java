package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;

import java.util.List;
import java.util.Optional;

public interface ProductoService {
    Producto crearProducto(Producto producto);
    Optional<Producto> obtenerProductoPorId(Integer id);
    List<Producto> obtenerProductos();
    List<Producto> obtenerProductosPorMetadato(Integer id);
    List<Producto> obtenerProductosPorUsuario(Integer id);
    Producto actualizarProducto(Integer id, Producto producto);
    void eliminarProducto(Integer id);
}
