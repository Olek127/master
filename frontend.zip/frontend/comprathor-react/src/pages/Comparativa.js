import React, { useState } from 'react';
import CompararProductos from '../components/comparativa/CompararProductos';
import { Link } from 'react-router-dom';
import './Pages.css';
import Select from 'react-select'
import Metadatos from '../components/metadatos/Metadatos';
import * as FaIcons from 'react-icons/fa';

const Comparativa = () => {
    const [metadatoSeleccionado, setmetadatoSeleccionado] = useState('');
    const [filtroUsuario, setFiltroUsuario] = useState('');
    const [comparativasFiltradas, setComparativasFiltradas] = useState('');

    const handleFiltroUsuarioChange = (selectedOption) => {
        setFiltroUsuario(selectedOption.value);
    };

    return  (
        <div className = 'comparativa'>
            <Link to="/comparativa-tiempo-real">
                <button className = 'boton-crear-comparativa'><FaIcons.FaClock className="icono-tiempo" /> Comparativa Tiempo Real</button>
            </Link>
            <Link to="/crear-comparativa">
                <button className = 'boton-crear-comparativa'><FaIcons.FaPlusCircle className="icono-pluscircle" /> Añadir Comparativa</button>
            </Link>

            <div className = 'filtros'>
                <Select
                    value = {{value: filtroUsuario, label: filtroUsuario ? "Comparativas propias" : "Comparativas de otros usuarios" }}
                    onChange={handleFiltroUsuarioChange}
                    className="filtro-usuario"
                    options = {[
                        { value : "", label: "Comparativas de otros usuarios" },
                        { value : "10", label: "Comparativas propias" },
                    ]}
                />
                <Metadatos setmetadatoSeleccionado={setmetadatoSeleccionado} />
            </div>
            <CompararProductos
                idUsuario = {filtroUsuario}
                idMetadatos = {metadatoSeleccionado.idmetadato}
            />
        </div>
    );
};

export default Comparativa;