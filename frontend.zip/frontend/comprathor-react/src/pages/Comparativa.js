import React from 'react';
import CompararProductos from '../components/comparativa/CompararProductos';
import { Link } from 'react-router-dom';
import './Pages.css';
import * as FaIcons from 'react-icons/fa';

const Comparativa = () => {

    const idUsuario = 1;

    return  (
        <div className = 'comparativa'>
            <Link to="/crear-comparativa">
                <button className = 'boton-crear-comparativa'>Añadir Comparativa <FaIcons.FaPlusCircle className="comparativa-mas-icono"/></button>
            </Link>
            <CompararProductos
                idUsuario = {idUsuario}
            />
        </div>
    );
};

export default Comparativa;