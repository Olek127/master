import React, {useState} from 'react';
import ListaProductos from '../components/listaproductos/ListaProductos';
import Metadatos from '../components/metadatos/Metadatos';
import { useParams } from 'react-router-dom';

const Productos = () => {
    const { idcategoria } = useParams();
    const [metadatoSeleccionado, setmetadatoSeleccionado] = useState(null);

    return  (
        <div className = 'productos'>
            <h1 className = "productos-titulo" >Lista de productos</h1>
            <Metadatos
                idcategoria={idcategoria}
                setmetadatoSeleccionado={setmetadatoSeleccionado}
            />
            <ListaProductos idmetadato={metadatoSeleccionado?.idmetadato} busqueda="" filtrarProductos={(productos, busqueda, metadato) => productos} />
        </div>
    );
};

export default Productos;