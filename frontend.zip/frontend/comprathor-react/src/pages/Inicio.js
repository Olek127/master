import React, {useState} from 'react';
import ListaProductos from '../components/listaproductos/ListaProductos';
import { useParams } from 'react-router-dom';

const Inicio = () => {
    const[busqueda, setBusqueda] = useState('');

    const handleBusquedaChange = (event) => {
        setBusqueda(event.target.value);
    };

    const filtrarProductos = (productos, busqueda) => {
        return productos.filter(producto =>
            producto.nombre.toLowerCase().includes(busqueda.toLowerCase())
        );
    };

    return  (
        <div className = 'inicio'>
            <h1>Inicio</h1>
            <input type="text" placeholder="Buscar Productos..." value={busqueda} onChange={handleBusquedaChange}/>
            {busqueda && <ListaProductos busqueda={busqueda} filtrarProductos={filtrarProductos} />}
        </div>
    );
};

export default Inicio;