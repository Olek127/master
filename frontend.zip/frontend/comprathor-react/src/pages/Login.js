import React, {useState} from 'react';
import LoginForm from '../components/login/LoginForm';
import { useParams } from 'react-router-dom';

const Login = () => {
    return  (
        <div className = 'login'>
            <LoginForm  />
        </div>
    );
};

export default Login;