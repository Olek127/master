//import logo from './logo.svg';
//import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
//import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
//import Header from './components/header/Header';
import ListaProductos from './components/listaproductos/ListaProductos';
//import Metadatos from './components/metadatos/Metadatos';
//import Categorias from './components/categorias/Categorias';
import Sidebar from './components/sidebar/Sidebar';
import Productos from './pages/Productos';
import Metadatos from './components/metadatos/Metadatos';
import Login from './pages/Login';
import Inicio from './pages/Inicio';
import Comparativa from './pages/Comparativa';
import AnadirComparativa from './components/comparativa/AnadirComparativa';


function App() {
  return (
   <Router>
        <Sidebar />
        <Routes>
            <Route path="/productos" element={<Productos />} />
            <Route path="/categoria/:idcategoria" element={<Productos />} />
            <Route path="/login/" element={<Login />} />
            <Route path="/inicio/" element={<Inicio />} />
            <Route path="/comparativa/" element={<Comparativa />} />
            <Route path="/crear-comparativa/" element={<AnadirComparativa />} />
        </Routes>
    </Router>
  );
}

export default App;
