
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ListaProductos from './components/listaproductos/ListaProductos';
import Sidebar from './components/sidebar/Sidebar';
import Productos from './pages/Productos';
import Metadatos from './components/metadatos/Metadatos';
import Login from './pages/Login';
import Inicio from './pages/Inicio';
import Comparativa from './pages/Comparativa';
import AnadirComparativa from './components/comparativa/AnadirComparativa';
import ComparativaTReal from './components/comparativa/ComparativaTReal';
import Keycloak from"keycloak-js";
import axios from 'axios';

const httpClient = axios.create();

let inicializarOpciones = {
    onLoad: 'login-required',
    checkLoginIframe: true,
    pckeMethod: 'S256',
    url: "http://localhost:8080/",
    realm: "SpringBootKeycloak",
    clientId: "login-app",
}

export const keycl = new Keycloak(inicializarOpciones);

keycl.init(inicializarOpciones).then((auth) => {
  if (!auth){
    window.location.reload();
  } else {

    httpClient.defaults.headers.common['Authorization'] = 'Bearer ' + keycl.token;

    keycl.onTokenExpired = () => {
      console.log('token expired')
    }
  }
}, () => {
  console.error("Authentication Failed")
});

function App() {
  return (

   <Router>
        <Sidebar/>
        <Routes>
            <Route path="/productos" element={<Productos />} />
            <Route path="/categoria/:idcategoria" element={<Productos />} />
            <Route path="/login/" element={<Login />} />
            <Route path="/inicio/" element={<Inicio />} />
            <Route path="/" element={<Inicio />} />
            <Route path="/comparativa/" element={<Comparativa />} />
            <Route path="/crear-comparativa/" element={<AnadirComparativa />} />
            <Route path="/comparativa-tiempo-real/" element={<ComparativaTReal />} />
        </Routes>
    </Router>

  );
}

export default App;
