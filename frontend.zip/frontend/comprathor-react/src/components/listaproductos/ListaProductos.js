import React, { useState, useEffect } from 'react';
import Card from 'react-bootstrap/Card';
import ListGroup from 'react-bootstrap/ListGroup';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import * as FaIcons from 'react-icons/fa';



import { API_BASE_URL } from '../../config'
import './ListaProductos.css';

const ListaProductos = ({ idmetadato, busqueda, filtrarProductos }) => {
    const [productos, setProductos] = useState([]);

    useEffect(() => {
        const fetchProductos = async () => {
            try {
                if(idmetadato || busqueda || filtrarProductos) {
                        const url = idmetadato
                        ? `${API_BASE_URL}/productos/metadatos/${idmetadato}`
                        : `${API_BASE_URL}/productos`;
                    const response = await fetch(url);
                    const data = await response.json();
                    setProductos(data);
                }
            } catch (error) {
                console.error('Error:', error);
            }
        };
        fetchProductos();
    }, [idmetadato]);

    const productosFiltrados = filtrarProductos(productos, busqueda);

    return (
        <div className = "lista-productos">
            <Row>
                {productosFiltrados.map(producto => (
                    <Col xs={12} md={6} lg={6} key={producto.id} className="lista-productos-columna">
                        <Card border = "light" key = {producto.id}>
                            <Row>
                                <Col xs={12} md={6}>
                                        <Card.Img className="lista-productos-imagen" src = {producto.imagen} alt = {producto.nombre} />
                                </Col>
                                <Col xs={12} md={6}>
                                    <Card.Body>
                                        <Card.Title className="lista-productos-titulo"><strong> {producto.nombre} </strong></Card.Title>
                                        <Card.Text className="lista-productos-descripcion">{producto.descripcion}</Card.Text>
                                    </Card.Body>
                                    <ListGroup className = "lista-grupo">
                                        <ListGroup.Item className="lista-productos-precio"><FaIcons.FaMoneyBill className="lista-productos-precio-icono"/> Precio | <strong>{producto.precio} € </strong></ListGroup.Item>
                                        <ListGroup.Item className="lista-productos-fabricante"><FaIcons.FaTruck className="lista-productos-fabricante-icono"/> Fabricante | <strong>{producto.fabricante}</strong> </ListGroup.Item>
                                        <ListGroup.Item className="lista-productos-valoracion"><FaIcons.FaStar className="lista-productos-valoracion-icono"/> Valoración | <strong>{producto.valoracion}</strong> </ListGroup.Item>
                                    </ListGroup>
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                ))}
            </Row>
        </div>
    );
}

export default ListaProductos;