import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { API_BASE_URL } from '../../config'
import Select from 'react-select'
import styled from 'styled-components';
import './Metadatos.css';
import * as FaIcons from 'react-icons/fa';


function Metadatos({ idcategoria, setmetadatoSeleccionado }) {
    const[metadatos, setMetadatos] = useState([]);
    const[metadatoSeleccionado] = useState(null);

    useEffect(() => {
        if (idcategoria) {
            fetch(`${API_BASE_URL}/metadatos/categoria/${idcategoria}`)
                .then(response => response.json())
                .then(data => setMetadatos(Array.isArray(data) ? data : []))
                .catch(error => console.error('Error:', error));
            }
        }, [idcategoria]);

    const options = [
        {value: '', label: <div><p> Todos los productos </p></div> },
        ...metadatos.map(metadato => ({
        value: metadato.idmetadato,
        label: (
            <div>
                 <p> {metadato.nombre} </p>
            </div>
        )
    })
    )];

    const handleSelectChange = (OpcionSeleccionada) => {
        const seleccion = metadatos.find(metadato => metadato.idmetadato === OpcionSeleccionada.value);
        setmetadatoSeleccionado(seleccion);
    };

    return(
        <div>
            <Select className="DropdownMetadatos" placeholder="Productos" options = {options}  onChange={handleSelectChange} />
            {metadatoSeleccionado && (
                <div> Nombre: {metadatoSeleccionado.nombre} </div>
            )}

        </div>
    );
}

export default Metadatos;