import { API_BASE_URL } from '../../config';
import React, {useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import * as FaIcons from 'react-icons/fa';
import './ComparativaTReal.css'

function ComparativaTReal() {
    const [productos, setProductos] = useState([]);
    const [productoSeleccionado1, setProductoSeleccionado1] = useState('');
    const [productoSeleccionado2, setProductoSeleccionado2] = useState('');
    const [producto1Informacion, setProducto1Informacion] = useState({});
    const [producto2Informacion, setProducto2Informacion] = useState({});
    const [metadatos, setMetadatos] = useState([]);
    const [metadatoSeleccionado,setMetadatoSeleccionado] = useState('');

    useEffect(() => {
            const fetchMetadatos = async () => {
                try {
                        const response = await fetch(`${API_BASE_URL}/metadatos`);
                        const datos = await response.json();
                        setMetadatos(datos);
                    }
                     catch (error) {
                    console.error(error || 'Error al cargar metadatos');
                }
            };


            fetchMetadatos();
        }, []);

        const handleCambioMetadato = (event) => {
            setMetadatoSeleccionado(event.target.value);
            setProducto1Informacion({});
            setProducto2Informacion({});
            setProductoSeleccionado1('');
            setProductoSeleccionado2('');
            fetchProductos(event.target.value);
        };

        const fetchProductos = async (idmetadato) => {
            try {
                    let response;
                    if(idmetadato) {
                        response = await fetch(`${API_BASE_URL}/productos/metadatos/${idmetadato}`);
                    }
                    else {
                        response = await fetch(`${API_BASE_URL}/productos`);
                    }
                    const datos = await response.json();
                    setProductos(datos);
                }
                 catch (error) {
                console.error(error || 'Error al cargar productos');
            }
        };

        const handleCambioProducto1 = (event) => {
            setProductoSeleccionado1(event.target.value);
            fetchProductoInformacion(event.target.value, setProducto1Informacion);
        };

        const handleCambioProducto2 = (event) => {
            setProductoSeleccionado2(event.target.value);
            fetchProductoInformacion(event.target.value, setProducto2Informacion);
        };

        const fetchProductoInformacion = async (idproducto, setProductoInformacion) => {
            try {
                const response = await fetch(`${API_BASE_URL}/productos/${idproducto}`);
                const datos = await response.json();
                setProductoInformacion(datos);
            }
            catch (error) {
                console.error(error || 'Error al cargar productos');
            }
        };

        return (

            <div className="comparativa-tiempo-real">
                <div className="d-metadatos">
                    <Link to="/comparativa">
                        <button className='boton-volver-atras-treal'><FaIcons.FaLongArrowAltLeft /> Volver</button>
                    </Link>
                    <select className="select-metadato" value = {metadatoSeleccionado} onChange={handleCambioMetadato}>
                        <option value=""> Seleccionar tipo</option>
                        {metadatos.map((metadato) => (
                            <option key={metadato.idmetadato} value={metadato.idmetadato}> {metadato.nombre}</option>
                        ))}
                    </select>
                </div>

                <div className="d-productos">
                    <select className="select-producto" value = {productoSeleccionado1} onChange={handleCambioProducto1}>
                        <option value=""> Seleccionar un producto</option>
                        {productos.map((producto) => (
                            <option key={producto.idproducto} value={producto.idproducto}> {producto.nombre}</option>
                        ))}
                    </select>
                </div>
                    {producto1Informacion.nombre && (
                        <>
                            <div className="informacion">
                                <img src={producto1Informacion.imagen} alt={producto1Informacion.nombre} />
                                <h2> {producto1Informacion.nombre} </h2>
                                <p> {producto1Informacion.descripcion} </p>
                                <p> <strong> Fabricante: </strong> {producto1Informacion.fabricante} </p>
                                <p> <strong> Precio: </strong> {producto1Informacion.precio} € </p>
                                <p> <strong> Valoración: </strong> {producto1Informacion.valoracion} <FaIcons.FaStar className="icono-global-comparativa icono-star"/>  </p>
                            </div>
                        </>
                    )}



                <div className="d-productos">
                    <select className="select-producto" value = {productoSeleccionado2} onChange={handleCambioProducto2}>
                        <option value=""> Seleccionar un producto</option>
                        {productos.map((producto) => (
                            <option key={producto.idproducto} value={producto.idproducto}> {producto.nombre}</option>
                        ))}
                    </select>
                </div>

                    {producto2Informacion.nombre && (
                        <>
                            <div className="informacion">
                                <img src={producto2Informacion.imagen} alt={producto2Informacion.nombre} />
                                <h2> {producto2Informacion.nombre} </h2>
                                <p> {producto2Informacion.descripcion} </p>
                                <p> <strong> Fabricante: </strong> {producto2Informacion.fabricante} </p>
                                <p> <strong> Precio: </strong> {producto2Informacion.precio} € </p>
                                <p> <strong> Valoración: </strong> {producto2Informacion.valoracion} <FaIcons.FaStar className="icono-global-comparativa icono-star"/> </p>
                            </div>
                        </>
                    )}


            </div>
        );

}

export default ComparativaTReal;