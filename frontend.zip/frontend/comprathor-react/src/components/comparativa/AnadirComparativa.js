import React, {useState} from 'react';
import { useParams, Link } from 'react-router-dom';
import './AnadirComparativa.css';
import { API_BASE_URL } from '../../config';
import Metadatos from '../metadatos/Metadatos';
import * as FaIcons from 'react-icons/fa';

const AnadirComparativa = () => {

    const idUsuario = 1;

    const [metadatoSeleccionado, setmetadatoSeleccionado] = useState(null);

    const [tituloComparativa, setTituloComparativa] = useState('');
    const [descripcionComparativa, setDescripcionComparativa] = useState('');

    const[enviado, setEnviado] = useState(false);

    const [primerProducto, setPrimerProducto] = useState({
        nombre: '', idmetadato: '', descripcion: '', fabricante: '', precio: 0, valoracion: 0, imagen: '', idusuario: idUsuario,
    });

    const [segundoProducto, setSegundoProducto] = useState({
            nombre: '', idmetadato: '', descripcion: '', fabricante: '', precio: 0, valoracion: 0, imagen: '', idusuario: idUsuario,
        });

    const primerProductoCambio = (e) => {
        setPrimerProducto({ ...primerProducto,[e.target.name]: e.target.value })
    };

    const segundoProductoCambio = (e) => {
        setSegundoProducto({ ...segundoProducto,[e.target.name]: e.target.value })
    };

    const subirProductos = async (e) => {
        e.preventDefault();

        try {
            const responsePrimerProducto = await fetch(`${API_BASE_URL}/productos`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(primerProducto),
            });
            console.log(primerProducto)
            const primerProductoCreado = await responsePrimerProducto.json();

            const responseSegundoProducto = await fetch(`${API_BASE_URL}/productos`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(segundoProducto),
            });

            console.log(segundoProducto)

            const segundoProductoCreado = await responseSegundoProducto.json();

            const comparativa1 = {
                idusuario: idUsuario,
                idproducto: primerProductoCreado.idproducto,
                idmetadato: primerProductoCreado.idmetadato,
                fechaCreacion: new Date().toISOString(),
                titulo: tituloComparativa,
                descripcion: descripcionComparativa,
                valoracion: 0,
            };
            console.log(comparativa1)

            const comparativa2 = {
                idusuario: idUsuario,
                idproducto: segundoProductoCreado.idproducto,
                idmetadato: segundoProductoCreado.idmetadato,
                fechaCreacion: new Date().toISOString(),
                titulo: tituloComparativa,
                descripcion: descripcionComparativa,
                valoracion: 0,
            };
            console.log(comparativa2)

            const responseComparativa1 = await fetch(`${API_BASE_URL}/comparativas`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(comparativa1),
            });

            const responseComparativa2 = await fetch(`${API_BASE_URL}/comparativas`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(comparativa2),
            });

            setEnviado(true);

            window.scrollTo({
                top: 0,
                behavior: 'smooth',
            });

        } catch (error) {
            console.error('Error :', error);
        }
    };

    return  (
        <div className = 'anadir-comparativa'>
            {enviado &&
                <div className = 'comparativa-anadida'>
                      <p> Comparativa añadida con éxito!</p>
                </div>
            }
            <div className = "parte-superior">
                <Link to="/comparativa">
                    <button className = 'boton-volver-atras'><FaIcons.FaLongArrowAltLeft /> Volver</button>
                </Link>
                <h2>Añadir una comparativa</h2>
            </div>

                <Metadatos setmetadatoSeleccionado={setmetadatoSeleccionado} className="dropdown-metadatos"/>
                <form onSubmit={subirProductos} className="formulario">
                    <table className='comparativa-tabla-superior'>
                       <thead>
                            <tr>
                                <th> Comparativa </th>
                            </tr>
                       </thead>
                       <tbody>
                            <tr>
                                <input type='text' name='titulo' placeholder="Título" value={tituloComparativa} onChange={(e) => setTituloComparativa(e.target.value)} />
                            </tr>
                            <tr>
                                <textarea type='text' name='descripcion' placeholder="Descripción..." value={descripcionComparativa} onChange={(e) => setDescripcionComparativa(e.target.value)}/>
                            </tr>
                       </tbody>
                    </table>

                    <table className='producto-tabla'>
                       <thead>
                            <tr>
                                <th> Producto 1 </th>
                                <th> Producto 2 </th>
                            </tr>
                       </thead>
                       <tbody>
                            <tr>
                                <td>

                                    <input type='text' name='nombre' placeholder='Nombre' value={primerProducto.nombre} onChange={primerProductoCambio} />
                                </td>
                                <td>

                                    <input type='text' name='nombre' placeholder='Nombre' value={segundoProducto.nombre} onChange={segundoProductoCambio} />
                                </td>
                            </tr>
                            <tr>
                                <td>

                                    <textarea type='text' name='descripcion' placeholder='Descripcion...' value={primerProducto.descripcion} onChange={primerProductoCambio} />
                                </td>
                                <td>

                                    <textarea type='text' name='descripcion' placeholder='Descripcion...' value={segundoProducto.descripcion} onChange={segundoProductoCambio} />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                     <FaIcons.FaTruck className="icono-global icono-truck"/>
                                     <input type='text' name='fabricante' placeholder='Fabricante' value={primerProducto.fabricante} onChange={primerProductoCambio} />
                                </td>
                                <td>
                                     <FaIcons.FaTruck className="icono-global icono-truck"/>
                                     <input type='text' name='fabricante' placeholder='Fabricante' value={segundoProducto.fabricante} onChange={segundoProductoCambio} />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                     <FaIcons.FaMoneyBill className="icono-global icono-moneybill"/>
                                     <input type='text' name='precio' placeholder='Precio' value={primerProducto.precio} onChange={primerProductoCambio} />
                                </td>
                                <td>
                                     <FaIcons.FaMoneyBill className="icono-global icono-moneybill"/>
                                     <input type='text' name='precio' placeholder='Precio' value={segundoProducto.precio} onChange={segundoProductoCambio} />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                     <FaIcons.FaStar className="icono-global icono-star"/>
                                     <input type='text' name='valoracion' placeholder='Valoracion' value={primerProducto.valoracion} onChange={primerProductoCambio} />
                                </td>
                                <td>
                                     <FaIcons.FaStar className="icono-global icono-star"/>
                                     <input type='text' name='valoracion' placeholder='Valoracion' value={segundoProducto.valoracion} onChange={segundoProductoCambio} />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                     <FaIcons.FaImage className="icono-global icono-image"/>
                                     <input type='text' name='imagen' placeholder='Imagen(URL)' value={primerProducto.imagen} onChange={primerProductoCambio} />
                                </td>
                                <td>
                                     <FaIcons.FaImage className="icono-global icono-image"/>
                                     <input type='text' name='imagen' placeholder='Imagen(URL)' value={segundoProducto.imagen} onChange={segundoProductoCambio} />
                                </td>
                            </tr>
                       </tbody>
                    </table>
                    <div className="boton-contenedor">
                        <button className="boton-anadir-comparativa" onClick={() => {
                            const idmetadatoselec = metadatoSeleccionado?.idmetadato;

                            setPrimerProducto({ ...primerProducto, idmetadato: idmetadatoselec });
                            setSegundoProducto({ ...segundoProducto, idmetadato: idmetadatoselec });
                            }}
                        type = 'submit'> <FaIcons.FaPlusCircle className="icono-pluscircle" /> Añadir nueva comparativa</button>
                    </div>
                </form>

        </div>
    );
};

export default AnadirComparativa;