import React, {useState} from 'react';
import { useParams } from 'react-router-dom';
import './AnadirComparativa.css';
import { API_BASE_URL } from '../../config';

const AnadirComparativa = () => {

    const idUsuario = 1;

    const [primerProducto, setPrimerProducto] = useState({
        nombre: '', idmetadato: 3, descripcion: '', fabricante: '', precio: 0, valoracion: 0, imagen: '', idusuario: idUsuario,
    });

    const [segundoProducto, setSegundoProducto] = useState({
            nombre: '', idmetadato: 3, descripcion: '', fabricante: '', precio: 0, valoracion: 0, imagen: '', idusuario: idUsuario,
        });

    const primerProductoCambio = (e) => {
        setPrimerProducto({ ...primerProducto,[e.target.name]: e.target.value })
    };

    const segundoProductoCambio = (e) => {
        setSegundoProducto({ ...segundoProducto,[e.target.name]: e.target.value })
    };

    const subirProductos = async (e) => {
        e.preventDefault();

        try {
            const responsePrimerProducto = await fetch(`${API_BASE_URL}/productos`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(primerProducto),
            });

            const primerProductoCreado = await responsePrimerProducto.json();

            const responseSegundoProducto = await fetch(`${API_BASE_URL}/productos`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(segundoProducto),
            });

            const segundoProductoCreado = await responseSegundoProducto.json();

            const comparativa1 = {
                idusuario: idUsuario,
                idproducto: primerProductoCreado.idproducto,
                fechaCreacion: new Date().toISOString(),
                titulo: 'Comparativa',
                descripcion: 'comaprativa descripcion',
                valoracion: 0,
            };

            const comparativa2 = {
                idusuario: idUsuario,
                idproducto: segundoProductoCreado.idproducto,
                fechaCreacion: new Date().toISOString(),
                titulo: 'Comparativa',
                descripcion: 'comaprativa descripcion',
                valoracion: 0,
            };

            const responseComparativa1 = await fetch(`${API_BASE_URL}/comparativas`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(comparativa1),
            });

            const responseComparativa2 = await fetch(`${API_BASE_URL}/comparativas`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(comparativa2),
            });

        } catch (error) {
            console.error('Error :', error);
        }
    };

    return  (
        <div className = 'anadir-comparativa'>
                <h2>Añadir una comparativa</h2>
                <form onSubmit={subirProductos}>
                    <div>
                        <label>Primer Producto</label>
                        <input type='text' name='nombre' placeholder='Nombre' value={primerProducto.nombre} onChange={primerProductoCambio} />
                        <input type='text' name='descripcion' placeholder='Descripcion' value={primerProducto.descripcion} onChange={primerProductoCambio} />
                        <input type='text' name='fabricante' placeholder='Fabricante' value={primerProducto.fabricante} onChange={primerProductoCambio} />
                        <input type='text' name='precio' placeholder='Precio' value={primerProducto.precio} onChange={primerProductoCambio} />
                        <input type='text' name='valoracion' placeholder='Valoracion' value={primerProducto.valoracion} onChange={primerProductoCambio} />
                        <input type='text' name='imagen' placeholder='Imagen(URL)' value={primerProducto.imagen} onChange={primerProductoCambio} />
                    </div>
                    <div>
                        <label>Segundo Producto</label>
                        <input type='text' name='nombre' placeholder='Nombre' value={segundoProducto.nombre} onChange={segundoProductoCambio} />
                        <input type='text' name='descripcion' placeholder='Descripcion' value={segundoProducto.descripcion} onChange={segundoProductoCambio} />
                        <input type='text' name='fabricante' placeholder='Fabricante' value={segundoProducto.fabricante} onChange={segundoProductoCambio} />
                        <input type='text' name='precio' placeholder='Precio' value={segundoProducto.precio} onChange={segundoProductoCambio} />
                        <input type='text' name='valoracion' placeholder='Valoracion' value={segundoProducto.valoracion} onChange={segundoProductoCambio} />
                        <input type='text' name='imagen' placeholder='Imagen(URL)' value={segundoProducto.imagen} onChange={segundoProductoCambio} />
                    </div>
                    <button type = 'submit'> Añadir Comparativa</button>
                </form>
        </div>
    );
};

export default AnadirComparativa;