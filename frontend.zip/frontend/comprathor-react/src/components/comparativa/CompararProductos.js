import React, { useState, useEffect } from 'react';
import { API_BASE_URL } from '../../config';
import Table from 'react-bootstrap/Table';
import './CompararProductos.css';
import * as FaIcons from 'react-icons/fa';

function CompararProductos({ idUsuario }) {
    const [comparativas, setComparativas] = useState([]);
    const [productos, setProductos] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const comparativasResponse = await fetch(`${API_BASE_URL}/comparativas/usuario/${idUsuario}`);
                const comparativasData = await comparativasResponse.json();
                setComparativas(Array.isArray(comparativasData) ? comparativasData : []);

                const productosResponse = await fetch(`${API_BASE_URL}/productos/usuario/${idUsuario}`);
                const productosData = await productosResponse.json();
                setProductos(Array.isArray(productosData) ? productosData : []);

            } catch (error) {
                setError(error.message || 'Error');
            }
        };


        fetchData();
    }, [idUsuario]);


    if (error) {
        return <div>Error: {error}</div>;
    }

    const comparativasOrdenadas = comparativas.slice().sort((a, b) => a.comparativaUsuarioProducto - b.comparativaUsuarioProducto);

    const comparativasEnPares = [];

    for(let i = 0; i < comparativasOrdenadas.length; i += 2) {
        const par = comparativasOrdenadas.slice(i, i+2);
        comparativasEnPares.push(par);
    }

    return (
        <div className="comparar-productos">
            {comparativasEnPares.map((comparativasDelProducto, index) => (
                <div key={index} className="seccion-producto">
                    {comparativasDelProducto.map((comparativa, innerIndex) => (
                        <div key={comparativa.idcomparativa}>
                            {innerIndex === 0 && (
                            <>
                                <h2>{comparativa.titulo}</h2>
                                <p>{comparativa.descripcion}</p>
                            </>
                            )}
                        </div>
                    ))}

                    <h2>Productos correspondientes</h2>

                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th> </th>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th>Fabricante</th>
                                <th>Precio</th>
                                <th>Valoración</th>
                            </tr>
                        </thead>

                        <tbody>
                            {productos

                                .filter((producto) => comparativasDelProducto.some((c) => c.idproducto.idproducto === producto.idproducto))
                                .map((producto) => (
                                    <tr key={producto.idproducto}>
                                        <td><img src = {producto.imagen} alt = {producto.nombre} /></td>
                                        <td>{producto.nombre}</td>
                                        <td>{producto.descripcion}</td>
                                        <td>{producto.fabricante}</td>
                                        <td>{producto.precio} <strong>€</strong></td>
                                        <td>{producto.valoracion} <FaIcons.FaStar className="lista-productos-estrellas-icono"/> </td>
                                    </tr>
                                ))}
                        </tbody>
                    </Table>
                </div>
            ))}
        </div>
    );
}

export default CompararProductos;
