import React, {useState, useEffect} from 'react';
import styled from 'styled-components';
import { Link, NavLink } from 'react-router-dom';
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from 'react-icons/ai';
import * as RiIcons from 'react-icons/ri';
import SidebarData from './SidebarData';
import SubMenu from './SubMenu';
import { IconContext } from 'react-icons/lib';
import { API_BASE_URL } from '../../config'

const iconMappings = {
    'FaIcons.FaPlug' : <FaIcons.FaPlug />,
    'FaIcons.FaCouch' : <FaIcons.FaCouch />,
    'FaIcons.FaTshirt' : <FaIcons.FaTshirt/>,
    'FaIcons.FaFutbol' : <FaIcons.FaFutbol />
}

const Nav = styled.div`
    background: #15171c;
    height: 80px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    padding: 1 1rem;
`;

const NavIcon = styled(Link)`
    margin-left: 2rem;
    font-size: 2rem;
    height: 100px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
`;

const SidebarWrap = styled.div`
    width: 100%;
`;

const SidebarNav = styled.nav`
    background: #15171c;
    width: 250px;
    height: 100vh;
    display: flex;
    justify-content: center;
    position: fixed;
    top: 0;
    left: ${({ sidebar }) => (sidebar ? '0' : '-100%')};
    transition: 350ms;
    z-index: 10;
`;

const Title = styled.h2`
    color: white;
    flex: 1;
    text-align: center;
`;




const Sidebar = () => {
    const [sidebar, setSidebar] = useState(false)
    const [categorias, setCategoria] = useState([]);

    useEffect(() => {
        fetch(`${API_BASE_URL}/categorias`)
          .then(response => response.json())
          .then(data => setCategoria(data))
          .catch(error => console.error('Error:', error));
      }, []);

      const updateSiderbarData = SidebarData.map(item => {
        if(item.title === 'Categorias') {
            return {
                ...item,
                subNav: categorias.map(categoria => ({
                    title: categoria.nombre,
                    path: `/categoria/${categoria.idcategoria}`,
                    icon: iconMappings[categoria.icono] || null,
                    iconClosed: <RiIcons.RiArrowDownSFill />,
                    iconOpened: <RiIcons.RiArrowUpSFill />,
                }))
            };
        }
        /**else if (item.title === 'Inicio') {
            return {
                ...item,
                icon: <FaIcons.FaUser />,
                path:'/user',
        };
        }**/
        return item;
      });


    const showSidebar = () => setSidebar(!sidebar)

    return  (
        <>
            <IconContext.Provider value={{ color: '#fff'}}>
                <Nav>
                    <NavIcon to='#'>
                        <FaIcons.FaBars onClick={showSidebar} />
                    </NavIcon>
                    <Title>Comprathor</Title>


                </Nav>
                <SidebarNav sidebar={sidebar}>
                    <SidebarWrap>
                        <NavIcon to='#'>
                            <AiIcons.AiOutlineClose onClick={showSidebar}/>
                        </NavIcon>
                        {updateSiderbarData.map((item, index) => {
                            return (
                                <SubMenu item={item} key={index}>
                                    {item.subNav && item.subNav.map((subItem, subIndex) => (
                                        <NavLink to={subItem.path} key={subIndex}>
                                            {subItem.title}
                                        </NavLink>
                                    ))}
                                </SubMenu>
                            );
                        })}
                    </SidebarWrap>
                </SidebarNav>
            </IconContext.Provider>
        </>
    );
};

export default Sidebar;