import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { API_BASE_URL } from '../../config'
import Select from 'react-select'
import styled from 'styled-components';
import './PaginaInicio.css';
import * as FaIcons from 'react-icons/fa';


function PaginaInicio() {
    const[productos, setProductos] = useState([]);
    const[metadatoSeleccionado] = useState(null);

    useEffect(() => {
        if (idcategoria) {
            fetch(`${API_BASE_URL}/productos/`)
                .then(response => response.json())
                .then(data => setProductos(Array.isArray(data) ? data : []))
                .catch(error => console.error('Error:', error));
            }
        }, []);


    return(
        <div>
        </div>
    );
}

export default PaginaInicio;