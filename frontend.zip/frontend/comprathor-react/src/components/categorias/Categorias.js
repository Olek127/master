import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { List } from 'react-bootstrap-icons';
import { API_BASE_URL } from '../../config'
//https://react-bootstrap.netlify.app/docs/components/navbar/
//import './Categorias.css';


function Categorias() {
    const [categorias, setCategoria] = useState([]);

    useEffect(() => {
        fetch(`${API_BASE_URL}/categorias`)
          .then(response => response.json())
          .then(data => setCategoria(data))
          .catch(error => console.error('Error:', error));
      }, []);

    return (
        <div className="categorias-menu">
            <NavDropdown title={<><List size={30} className="mr-2" /> Categorías</>} id="basic-nav-dropdown" drop="down">
                  {categorias.map(categoria => (
                    <NavDropdown.Item key={categoria.id}>
                        <Link to={`/categoria/${categoria.id}`}>{categoria.nombre}</Link>
                    </NavDropdown.Item>
                  ))}
            </NavDropdown>
        </div>
    );
}

export default Categorias;