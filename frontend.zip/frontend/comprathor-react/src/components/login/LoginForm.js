import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { List } from 'react-bootstrap-icons';
import { API_BASE_URL } from '../../config'
import * as FaIcons from 'react-icons/fa';
import './LoginForm.css';

function LoginForm() {
    return (
        <div className="login-global">
            <div className="login-formulario">
                <form action = "">
                    <h1>Login</h1>
                    <div className="input-caja">
                        <input type = "text" placeholder = 'Usuario' required />
                        <FaIcons.FaUser className="icono"/>
                    </div>
                    <div className="input-caja">
                        <input type = "password" placeholder = 'Contraseña' required />
                        <FaIcons.FaLock className="icono"/>
                    </div>
                    <div className="olvidado">
                        <a href="#"> Has olvidado la contraseña? </a>
                    </div>

                    <button className="button-login" type = "submit">Login </button>

                    <div className="registrarse">
                        <a href="#">Registrarse</a>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default LoginForm;