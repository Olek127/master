package com.comprathor.comprathor.modelos;

import com.comprathor.comprathor.entidades.TipoUsuario;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
//import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UsuarioModelo implements Serializable {
    private Integer IDUsuario;
    private String Nombre;
    private String correoelectronico;
    private String Contrasena;
    private Date Fecha_Registro;

    @Enumerated(EnumType.STRING)
    private TipoUsuario tipoUsuario;

    public UsuarioModelo(Integer idUsuario) {
        this.IDUsuario = idUsuario;
    }

}


