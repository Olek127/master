package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.entidades.Usuario;
import com.comprathor.comprathor.modelos.UsuarioModelo;

import java.util.List;
import java.util.Optional;

public interface UsuarioService {
    UsuarioModelo registrarUsuario(UsuarioModelo usuario);
    Optional<UsuarioModelo> obtenerUsuarioPorId(Integer id);
    List<UsuarioModelo> obtenerUsuarios();
    UsuarioModelo actualizarUsuario(Integer id, UsuarioModelo usuario);
    void eliminarUsuario(Integer id);

}
