package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.entidades.Usuario;
import com.comprathor.comprathor.modelos.ProductoModelo;
import com.comprathor.comprathor.modelos.UsuarioModelo;
import com.comprathor.comprathor.repositorio.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public UsuarioModelo registrarUsuario(UsuarioModelo usuario) {
        Usuario usuariocreado = usuarioRepository.save(convertirUsuarioModeloAUsuario(usuario));

        return convertirUsuarioAUsuarioModelo(usuariocreado);
    }

    @Override
    public Optional<UsuarioModelo> obtenerUsuarioPorId(Integer id) {
        Optional<Usuario> usuarioOptional = usuarioRepository.findById(id);
        return usuarioOptional.map(this::convertirUsuarioAUsuarioModelo);
    }

    @Override
    public List<UsuarioModelo> obtenerUsuarios() {
        List<Usuario> usuarios = usuarioRepository.findAll();
        return usuarios.stream()
                .map(this::convertirUsuarioAUsuarioModelo)
                .collect(Collectors.toList());
    }

    @Override
    public UsuarioModelo actualizarUsuario(Integer id, UsuarioModelo usuario) {
        if (usuarioRepository.existsById(id))
        {
            usuario.setIDUsuario(id);
            Usuario usuarioAct = usuarioRepository.save(convertirUsuarioModeloAUsuario(usuario));
            return convertirUsuarioAUsuarioModelo(usuarioAct);
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }

    @Override
    public void eliminarUsuario(Integer id) {
        if (usuarioRepository.existsById(id))
        {
            usuarioRepository.deleteById(id);
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }

    private UsuarioModelo convertirUsuarioAUsuarioModelo(Usuario usuario) {
        return UsuarioModelo.builder()
                .IDUsuario(usuario.getIDUsuario())
                .Nombre(usuario.getNombre())
                .correoelectronico(usuario.getCorreoelectronico())
                .Contrasena(usuario.getContrasena())
                .Fecha_Registro(usuario.getFecha_Registro())
                .tipoUsuario(usuario.getTipoUsuario())
                .build();
    }

    private Usuario convertirUsuarioModeloAUsuario(UsuarioModelo usuarioModelo) {
        return Usuario.builder()
                .IDUsuario(usuarioModelo.getIDUsuario())
                .Nombre(usuarioModelo.getNombre())
                .correoelectronico(usuarioModelo.getCorreoelectronico())
                .Contrasena(usuarioModelo.getContrasena())
                .Fecha_Registro(usuarioModelo.getFecha_Registro())
                .tipoUsuario(usuarioModelo.getTipoUsuario())
                .build();
    }

}
