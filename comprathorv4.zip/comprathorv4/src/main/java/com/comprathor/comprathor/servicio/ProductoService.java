package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.modelos.ProductoModelo;

import java.util.List;
import java.util.Optional;

public interface ProductoService {
    ProductoModelo crearProducto(ProductoModelo producto);
    Optional<ProductoModelo> obtenerProductoPorId(Integer id);
    List<ProductoModelo> obtenerProductos();
    List<ProductoModelo> obtenerProductosPorMetadato(Integer id);
    List<ProductoModelo> obtenerProductosPorUsuario(Integer id);
    ProductoModelo actualizarProducto(Integer id, ProductoModelo producto);
    void eliminarProducto(Integer id);
}
