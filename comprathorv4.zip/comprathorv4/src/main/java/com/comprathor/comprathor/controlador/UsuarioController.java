package com.comprathor.comprathor.controlador;

import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.entidades.Usuario;
import com.comprathor.comprathor.modelos.UsuarioModelo;
import com.comprathor.comprathor.repositorio.UsuarioRepository;
import com.comprathor.comprathor.servicio.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/usuarios")
//@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:8888" })
public class UsuarioController {
    @Autowired
    private UsuarioService usuarioService;

    @PostMapping(consumes = "application/json")
    public ResponseEntity<UsuarioModelo> crearUsuario(@RequestBody UsuarioModelo usuario) {
        UsuarioModelo nuevoUsuario = usuarioService.registrarUsuario(usuario);
        return new ResponseEntity<>(nuevoUsuario, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<UsuarioModelo> obtenerUsuarioPorId(@PathVariable Integer id) {
        Optional<UsuarioModelo> usuario = usuarioService.obtenerUsuarioPorId(id);
        return usuario.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<List<UsuarioModelo>> obtenerUsuarios() {
        List<UsuarioModelo> usuario = usuarioService.obtenerUsuarios();
        return new ResponseEntity<>(usuario, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UsuarioModelo> actualizarUsuario(@PathVariable Integer id, @RequestBody UsuarioModelo usuario) {
        UsuarioModelo usuarioActu = usuarioService.actualizarUsuario(id, usuario);
        return ResponseEntity.ok(usuarioActu);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarUsuario(@PathVariable Integer id) {
        usuarioService.eliminarUsuario(id);
        return ResponseEntity.noContent().build();
    }


}
