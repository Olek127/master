package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Comparativa;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.modelos.ComparativaModelo;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;
import java.util.Optional;

public interface ComparativaService {
    ComparativaModelo crearComparativa(ComparativaModelo comparativa);
    Optional<ComparativaModelo> obtenerComparativaPorId(Integer id);
    List<ComparativaModelo> obtenerComparativas();
    List<ComparativaModelo> obtenerComparativasPorUsuario(Integer idUsuario);
    ComparativaModelo actualizarComparativa(Integer id, ComparativaModelo comparativa);
    void eliminarComparativa(Integer id);
}
