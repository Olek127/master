package com.comprathor.comprathor.entidades;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Metadatos {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_Metadato")
    private Integer IDMetadato;
    //@Column(name = "ID_Categoria")
    @ManyToOne
    @JoinColumn(name = "ID_Categoria", nullable = false)
    private Categoria IDCategoria;
    private String Nombre;
    @Enumerated(EnumType.STRING)
    @Column(name = "Tipo_Dato")
    private TipoDato tipoDato;

    public Metadatos(Integer idMetadatos) {
        this.IDMetadato = idMetadatos;
    }
}
