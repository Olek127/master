package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.modelos.MetadatosModelo;
import com.comprathor.comprathor.modelos.ProductoModelo;
import com.comprathor.comprathor.repositorio.MetadatosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MetadatosServiceImpl implements  MetadatosService{

    @Autowired
    private MetadatosRepository metadatosRepository;
    @Override
    public MetadatosModelo crearMetadato(MetadatosModelo metadatosModelo) {
        return convertirMetadatosAMetadatosModelo(metadatosRepository.save(convertirMetadatosModeloAMetadatos(metadatosModelo)));
    }

    @Override
    public Optional<MetadatosModelo> obtenerMetadatoPorId(Integer id) {
        return metadatosRepository.findById(id).map(this::convertirMetadatosAMetadatosModelo);
    }

    @Override
    public List<MetadatosModelo> obtenerMetadatos() {
        return metadatosRepository.findAll().stream()
                .map(this::convertirMetadatosAMetadatosModelo)
                .collect(Collectors.toList());
    }

    @Override
    public List<MetadatosModelo> obtenerMetadatosPorCategoria(Integer id) {
        return metadatosRepository.findByIDCategoria_IDCategoria(id).stream()
                .map(this::convertirMetadatosAMetadatosModelo)
                .collect(Collectors.toList());
    }

    @Override
    public MetadatosModelo actualizarMetadato(Integer id, MetadatosModelo metadatosModelo) {
        if (metadatosRepository.existsById(id))
        {
            metadatosModelo.setIDMetadato(id);
            return convertirMetadatosAMetadatosModelo(metadatosRepository.save(convertirMetadatosModeloAMetadatos(metadatosModelo)));
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }
    @Override
    public void eliminarMetadato(Integer id) {
        if (metadatosRepository.existsById(id))
        {
            metadatosRepository.deleteById(id);
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }

    private MetadatosModelo convertirMetadatosAMetadatosModelo(Metadatos metadatos) {
        return MetadatosModelo.builder()
                .IDMetadato(metadatos.getIDMetadato())
                .IDCategoria(metadatos.getIDCategoria())
                .Nombre(metadatos.getNombre())
                .tipoDato(metadatos.getTipoDato())
                .build();
    }

    private Metadatos convertirMetadatosModeloAMetadatos(MetadatosModelo metadatosModelo) {
        return Metadatos.builder()
                .IDMetadato(metadatosModelo.getIDMetadato())
                .IDCategoria(metadatosModelo.getIDCategoria())
                .Nombre(metadatosModelo.getNombre())
                .tipoDato(metadatosModelo.getTipoDato())
                .build();
    }
}
