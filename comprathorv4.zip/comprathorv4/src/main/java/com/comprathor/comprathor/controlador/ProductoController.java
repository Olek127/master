package com.comprathor.comprathor.controlador;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.modelos.ProductoModelo;
import com.comprathor.comprathor.servicio.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/productos", produces = "application/json")
//@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:8888" })
public class ProductoController {
    @Autowired
    private ProductoService productoService;

    @PostMapping(consumes = "application/json")
    public ResponseEntity<ProductoModelo> crearProducto(@RequestBody ProductoModelo producto) {
        ProductoModelo productonuevo = productoService.crearProducto(producto);
        return new ResponseEntity<>(productonuevo, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductoModelo> obtenerProductoPorId(@PathVariable Integer id) {
        Optional<ProductoModelo> productoModelo = productoService.obtenerProductoPorId(id);
        return productoModelo.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<List<ProductoModelo>> obtenerProductos() {
        List<ProductoModelo> productos = productoService.obtenerProductos();
        return new ResponseEntity<>(productos, HttpStatus.OK);
    }

    @GetMapping("/metadatos/{id}")
    public ResponseEntity<List<ProductoModelo>> obtenerProductosPorCategoria(@PathVariable Integer id) {
        List<ProductoModelo> productos = productoService.obtenerProductosPorMetadato(id);
        return new ResponseEntity<>(productos, HttpStatus.OK);
    }

    @GetMapping("/usuario/{id}")
    public ResponseEntity<List<ProductoModelo>> obtenerProductosPorUsuario(@PathVariable Integer id) {
        List<ProductoModelo> productos = productoService.obtenerProductosPorUsuario(id);
        return new ResponseEntity<>(productos, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProductoModelo> actualizarProducto(@PathVariable Integer id, @RequestBody ProductoModelo producto) {
        ProductoModelo productosActu = productoService.actualizarProducto(id, producto);
        return ResponseEntity.ok(productosActu);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<List<ProductoModelo>> eliminarProducto(@PathVariable Integer id) {
        productoService.eliminarProducto(id);
        return ResponseEntity.noContent().build();
    }


}
