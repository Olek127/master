package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Categoria;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.modelos.CategoriaModelo;

import java.util.List;
import java.util.Optional;

public interface CategoriaService {
    CategoriaModelo crearCategoria(CategoriaModelo categoria);
    Optional<CategoriaModelo> obtenerCategoriaPorId(Integer id);
    List<CategoriaModelo> obtenerCategorias();
    CategoriaModelo actualizarCategoria(Integer id, CategoriaModelo categoria);
    void eliminarCategoria(Integer id);
}
