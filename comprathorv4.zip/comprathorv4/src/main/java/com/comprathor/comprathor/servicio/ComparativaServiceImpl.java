package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Categoria;
import com.comprathor.comprathor.entidades.Comparativa;
import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.modelos.ComparativaModelo;
import com.comprathor.comprathor.modelos.MetadatosModelo;
import com.comprathor.comprathor.repositorio.ComparativaRepository;
import com.comprathor.comprathor.repositorio.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ComparativaServiceImpl implements ComparativaService{
    @Autowired
    private ComparativaRepository comparativaRepository;
    @Autowired
    ProductoRepository productoRepository;
    @Override
    public ComparativaModelo crearComparativa(ComparativaModelo comparativa) {
        return convertirComparativaAComparativaModelo(comparativaRepository.save(convertirComparativaModeloAComparativa(comparativa)));
    }

    @Override
    public Optional<ComparativaModelo> obtenerComparativaPorId(Integer id) {
        Optional<Comparativa> comparativaOptional = comparativaRepository.findById(id);
        return comparativaOptional.map(this::convertirComparativaAComparativaModelo);
    }

    @Override
    public List<ComparativaModelo> obtenerComparativas() {
        List<Comparativa> comparativas = comparativaRepository.findAll();
        return comparativas.stream()
                .map(this::convertirComparativaAComparativaModelo)
                .collect(Collectors.toList());
    }

    @Override
    public List<ComparativaModelo> obtenerComparativasPorUsuario(Integer idUsuario) {
        List<Comparativa> comparativas = comparativaRepository.findByIDUsuario_IDUsuario(idUsuario);
        return comparativas.stream()
                .map(this::convertirComparativaAComparativaModelo)
                .collect(Collectors.toList());
    }

    @Override
    public ComparativaModelo actualizarComparativa(Integer id, ComparativaModelo comparativaModelo) {
        if (comparativaRepository.existsById(id))
        {
            comparativaModelo.setIDComparativa(id);
            return convertirComparativaAComparativaModelo(comparativaRepository.save(convertirComparativaModeloAComparativa(comparativaModelo)));

        }
        else {
            throw new EntityNotFoundException("La comparativa con ID " + id + " no existe");
        }
    }

    @Override
    public void eliminarComparativa(Integer id) {
        if (comparativaRepository.existsById(id))
        {
            comparativaRepository.deleteById(id);
        }
        else {
            throw new EntityNotFoundException("La comparativa con ID " + id + " no existe");
        }
    }

    private ComparativaModelo convertirComparativaAComparativaModelo(Comparativa comparativa) {
        return ComparativaModelo.builder()
                .IDComparativa(comparativa.getIDComparativa())
                .IDUsuario(comparativa.getIDUsuario())
                .IDProducto1(comparativa.getIDProducto1())
                .IDProducto2(comparativa.getIDProducto2())
                .Titulo(comparativa.getTitulo())
                .Descripcion(comparativa.getDescripcion())
                .Valoracion(comparativa.getValoracion())
                .build();
    }

    private Comparativa convertirComparativaModeloAComparativa(ComparativaModelo comparativaModelo) {
        return Comparativa.builder()
                .IDComparativa(comparativaModelo.getIDComparativa())
                .IDUsuario(comparativaModelo.getIDUsuario())
                .IDProducto1(comparativaModelo.getIDProducto1())
                .IDProducto2(comparativaModelo.getIDProducto2())
                .Titulo(comparativaModelo.getTitulo())
                .Descripcion(comparativaModelo.getDescripcion())
                .Valoracion(comparativaModelo.getValoracion())
                .build();
    }
}
