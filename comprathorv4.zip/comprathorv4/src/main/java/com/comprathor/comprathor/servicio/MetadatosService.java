package com.comprathor.comprathor.servicio;


import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.modelos.MetadatosModelo;

import java.util.List;
import java.util.Optional;

public interface MetadatosService {
    MetadatosModelo crearMetadato(MetadatosModelo metadato);
    Optional<MetadatosModelo> obtenerMetadatoPorId(Integer id);
    List<MetadatosModelo> obtenerMetadatos();
    List<MetadatosModelo> obtenerMetadatosPorCategoria(Integer id);
    MetadatosModelo actualizarMetadato(Integer id, MetadatosModelo metadato);
    void eliminarMetadato(Integer id);
}
