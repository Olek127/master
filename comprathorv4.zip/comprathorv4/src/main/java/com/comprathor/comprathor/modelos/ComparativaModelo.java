package com.comprathor.comprathor.modelos;

import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.entidades.Usuario;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ComparativaModelo {
    private Integer IDComparativa;
    private Usuario IDUsuario;
    private Producto IDProducto1;
    private Producto IDProducto2;
    private String Titulo;
    private String Descripcion;
    private BigDecimal Valoracion;
    public ComparativaModelo(Integer idComparativas) {
        this.IDComparativa = idComparativas;
    }
}
