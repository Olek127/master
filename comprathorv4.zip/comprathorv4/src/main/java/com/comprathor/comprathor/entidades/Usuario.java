package com.comprathor.comprathor.entidades;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;
//import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_Usuario")
    private Integer IDUsuario;
    @Column(name = "Nombre")
    private String Nombre;
    @Column(name = "Correo_electronico")
    private String correoelectronico;
    private String Contrasena;
    @Column(name = "Fecha_Registro")
    private Date Fecha_Registro;

    @Enumerated(EnumType.STRING)
    @Column(name = "Tipo_usuario")
    private TipoUsuario tipoUsuario;

    public Usuario(Integer idUsuario) {
        this.IDUsuario = idUsuario;
    }

}


