package com.comprathor.comprathor.entidades;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Comparativa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_Comparativa")
    private Integer IDComparativa;

    //@Column(name = "ID_Usuario")
    @ManyToOne
    @JoinColumn(name = "ID_Usuario", nullable = false)
    private Usuario IDUsuario;

    @ManyToOne
    @JoinColumn(name = "ID_Producto_1", nullable = false)
    private Producto IDProducto1;

    @ManyToOne
    @JoinColumn(name = "ID_Producto_2", nullable = false)
    private Producto IDProducto2;

    private String Titulo;

    private String Descripcion;

    private BigDecimal Valoracion;

    public Comparativa(Integer idComparativas) {
        this.IDComparativa = idComparativas;
    }
}
