package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.modelos.ProductoModelo;
import com.comprathor.comprathor.repositorio.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProductoServiceImpl implements ProductoService{

    @Autowired
    private ProductoRepository productoRepository;
    @Override
    public ProductoModelo crearProducto(ProductoModelo producto) {
        Producto productocreado = productoRepository.save(convertirProductoModeloAProducto(producto));
        return convertirProductoAProductoModelo(productocreado);
    }

    @Override
    public Optional<ProductoModelo> obtenerProductoPorId(Integer id) {
        Optional<Producto> optionalProducto = productoRepository.findById(id);
        return optionalProducto.map(this::convertirProductoAProductoModelo);
    }

    @Override
    public List<ProductoModelo> obtenerProductos() {
        List<Producto> productos = productoRepository.findAll();
        return productos.stream()
                .map(this::convertirProductoAProductoModelo)
                .collect(Collectors.toList());
    }

    @Override
    public List<ProductoModelo> obtenerProductosPorMetadato(Integer id) {
        List<Producto> productos = productoRepository.findByIDMetadato_IDMetadato(id);
        return productos.stream()
                .map(this::convertirProductoAProductoModelo)
                .collect(Collectors.toList());
    }

    @Override
    public List<ProductoModelo> obtenerProductosPorUsuario(Integer id) {
        List<Producto> productos = productoRepository.findByIDUsuario_IDUsuario(id);
        return productos.stream()
                .map(this::convertirProductoAProductoModelo)
                .collect(Collectors.toList());
    }

    @Override
    public ProductoModelo actualizarProducto(Integer id, ProductoModelo productoModelo) {
        if (productoRepository.existsById(id))
        {
            productoModelo.setIDProducto(id);
            Producto productoAct = productoRepository.save(convertirProductoModeloAProducto(productoModelo));
             return convertirProductoAProductoModelo(productoAct);
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }

    @Override
    public void eliminarProducto(Integer id) {
        if (productoRepository.existsById(id))
        {
            productoRepository.deleteById(id);
        }
        else {
            throw new EntityNotFoundException("El metadato con ID " + id + " no existe");
        }
    }

    private ProductoModelo convertirProductoAProductoModelo(Producto producto) {
        return ProductoModelo.builder()
                .IDProducto(producto.getIDProducto())
                .IDMetadato(producto.getIDMetadato())
                .Nombre(producto.getNombre())
                .Descripcion(producto.getDescripcion())
                .Fabricante(producto.getFabricante())
                .Precio(producto.getPrecio())
                .Valoracion(producto.getValoracion())
                .Imagen(producto.getImagen())
                .IDUsuario(producto.getIDUsuario())
                .build();
    }

    private Producto convertirProductoModeloAProducto(ProductoModelo productoModelo) {
        return Producto.builder()
                .IDProducto(productoModelo.getIDProducto())
                .IDMetadato(productoModelo.getIDMetadato())
                .Nombre(productoModelo.getNombre())
                .Descripcion(productoModelo.getDescripcion())
                .Fabricante(productoModelo.getFabricante())
                .Precio(productoModelo.getPrecio())
                .Valoracion(productoModelo.getValoracion())
                .Imagen(productoModelo.getImagen())
                .IDUsuario(productoModelo.getIDUsuario())
                .build();
    }
}
