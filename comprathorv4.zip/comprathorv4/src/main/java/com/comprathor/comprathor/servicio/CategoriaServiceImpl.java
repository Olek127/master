package com.comprathor.comprathor.servicio;

import com.comprathor.comprathor.entidades.Categoria;
import com.comprathor.comprathor.entidades.Comparativa;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.modelos.CategoriaModelo;
import com.comprathor.comprathor.modelos.ComparativaModelo;
import com.comprathor.comprathor.repositorio.CategoriaRepository;
import com.comprathor.comprathor.repositorio.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CategoriaServiceImpl implements CategoriaService{

    @Autowired
    CategoriaRepository categoriaRepository;
    @Override
    public CategoriaModelo crearCategoria(CategoriaModelo categoriaModelo) {

        return convertirCategoriaACategoriaModelo(categoriaRepository.save(convertirCategoriaModeloACategoria(categoriaModelo)));
    }

    @Override
    public Optional<CategoriaModelo> obtenerCategoriaPorId(Integer id) {

        return categoriaRepository.findById(id).map(this::convertirCategoriaACategoriaModelo);
    }

    @Override
    public List<CategoriaModelo> obtenerCategorias() {

        return categoriaRepository.findAll().stream().map(this::convertirCategoriaACategoriaModelo).collect(Collectors.toList());
    }

    @Override
    public CategoriaModelo actualizarCategoria(Integer id, CategoriaModelo categoriaModelo) {
        if (categoriaRepository.existsById(id)) {
            categoriaModelo.setIDCategoria(id);
            return convertirCategoriaACategoriaModelo(categoriaRepository.save(convertirCategoriaModeloACategoria(categoriaModelo)));
        } else {
            throw new EntityNotFoundException("La categoría con ID " + id + " no existe");
        }
    }

    @Override
    public void eliminarCategoria(Integer id) {
        if (categoriaRepository.existsById(id)) {
            categoriaRepository.deleteById(id);
        } else {
            throw new EntityNotFoundException("La categoría con ID " + id + " no existe");
        }
    }

    private CategoriaModelo convertirCategoriaACategoriaModelo(Categoria categoria) {
        return CategoriaModelo.builder()
                .IDCategoria(categoria.getIDCategoria())
                .Nombre(categoria.getNombre())
                .Descripcion(categoria.getDescripcion())
                .Icono(categoria.getIcono())
                .CantidadProductos(categoria.getCantidadProductos())
                .build();
    }

    private Categoria convertirCategoriaModeloACategoria(CategoriaModelo categoriaModelo) {
        return Categoria.builder()
                .IDCategoria(categoriaModelo.getIDCategoria())
                .Nombre(categoriaModelo.getNombre())
                .Descripcion(categoriaModelo.getDescripcion())
                .Icono(categoriaModelo.getIcono())
                .CantidadProductos(categoriaModelo.getCantidadProductos())
                .build();
    }
}
