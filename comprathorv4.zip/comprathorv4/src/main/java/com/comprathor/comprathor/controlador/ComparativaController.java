package com.comprathor.comprathor.controlador;

import com.comprathor.comprathor.entidades.Comparativa;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.modelos.ComparativaModelo;
import com.comprathor.comprathor.servicio.ComparativaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/comparativas", produces = "application/json")
//@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:8888" })
public class ComparativaController {
    @Autowired
    private ComparativaService comparativaService;

    @PostMapping(consumes = "application/json")
    public ResponseEntity<ComparativaModelo> crearComparativa(@RequestBody ComparativaModelo comparativa) {
        ComparativaModelo comparativanueva = comparativaService.crearComparativa(comparativa);
        return new ResponseEntity<>(comparativanueva, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ComparativaModelo> obtenerComparativaPorId(@PathVariable Integer id) {
        return comparativaService.obtenerComparativaPorId(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<List<ComparativaModelo>> obtenerComparativas() {
        List<ComparativaModelo> comparativas = comparativaService.obtenerComparativas();
        return new ResponseEntity<>(comparativas, HttpStatus.OK);
    }

    @GetMapping("/usuario/{idUsuario}")
    public ResponseEntity<List<ComparativaModelo>> obtenerProductosPorUsuario(@PathVariable Integer idUsuario) {
        List<ComparativaModelo> comparativas = comparativaService.obtenerComparativasPorUsuario(idUsuario);
        return new ResponseEntity<>(comparativas, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ComparativaModelo> actualizarComparativa(@PathVariable Integer id, @RequestBody ComparativaModelo comparativa) {
        ComparativaModelo comparativaActualizada = comparativaService.actualizarComparativa(id, comparativa);
        return ResponseEntity.ok(comparativaActualizada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarComparativa(@PathVariable Integer id) {
        comparativaService.eliminarComparativa(id);
        return ResponseEntity.noContent().build();
    }
}
