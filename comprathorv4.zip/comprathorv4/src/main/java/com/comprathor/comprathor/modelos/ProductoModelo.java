package com.comprathor.comprathor.modelos;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Usuario;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProductoModelo implements Serializable {
    private Integer IDProducto;
    private Metadatos IDMetadato;
    private Usuario IDUsuario;
    private String Nombre;
    private String Descripcion;
    private String Fabricante;
    private BigDecimal Precio;
    private BigDecimal Valoracion;
    private String Imagen;

    public ProductoModelo(Integer idProductos) {
        this.IDProducto = idProductos;
    }

}
