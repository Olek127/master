package com.comprathor.comprathor.controlador;

import com.comprathor.comprathor.entidades.Categoria;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.modelos.CategoriaModelo;
import com.comprathor.comprathor.servicio.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/categorias", produces = "application/json")
//@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:8888" })
public class CategoriaController {
    @Autowired
    private CategoriaService categoriaService;

    @PostMapping(consumes = "application/json")
    public ResponseEntity<CategoriaModelo> crearCategoria(@RequestBody CategoriaModelo categoria) {
        CategoriaModelo categorianueva = categoriaService.crearCategoria(categoria);
        return new ResponseEntity<>(categorianueva, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CategoriaModelo> obtenerCategoriaPorId(@PathVariable Integer id) {
        Optional<CategoriaModelo> categoria = categoriaService.obtenerCategoriaPorId(id);
        return categoria.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<List<CategoriaModelo>> obtenerCategorias() {
        List<CategoriaModelo> categorias = categoriaService.obtenerCategorias();
        return new ResponseEntity<>(categorias, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CategoriaModelo> actualizarCategoria(@PathVariable Integer id, @RequestBody CategoriaModelo categoria) {
        CategoriaModelo categoriaAct = categoriaService.actualizarCategoria(id, categoria);
        return ResponseEntity.ok(categoriaAct);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarCategoria(@PathVariable Integer id) {
        categoriaService.eliminarCategoria(id);
        return ResponseEntity.noContent().build();
    }

}
