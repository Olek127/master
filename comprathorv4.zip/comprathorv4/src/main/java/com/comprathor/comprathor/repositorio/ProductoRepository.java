package com.comprathor.comprathor.repositorio;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {
    List<Producto> findByIDMetadato_IDMetadato(Integer idMetadato);
    List<Producto> findByIDUsuario_IDUsuario(Integer idUsuario);

}
