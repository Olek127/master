package com.comprathor.comprathor.entidades;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Categoria {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_Categoria")
    private Integer IDCategoria;

    private String Nombre;
    private String Descripcion;
    private String Icono;
    @Column(name = "Cantidad_Productos")
    private Integer CantidadProductos;

    public Categoria(Integer idCategoria) {
        this.IDCategoria = idCategoria;
    }

}
