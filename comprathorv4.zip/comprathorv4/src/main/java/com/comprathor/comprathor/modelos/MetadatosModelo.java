package com.comprathor.comprathor.modelos;
import com.comprathor.comprathor.entidades.Categoria;
import com.comprathor.comprathor.entidades.TipoDato;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MetadatosModelo {
    private Integer IDMetadato;
    private Categoria IDCategoria;
    private String Nombre;
    @Enumerated(EnumType.STRING)
    private TipoDato tipoDato;

    public MetadatosModelo(Integer idMetadatos) {
        this.IDMetadato = idMetadatos;
    }
}
