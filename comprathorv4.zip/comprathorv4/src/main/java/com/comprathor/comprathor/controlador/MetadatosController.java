package com.comprathor.comprathor.controlador;

import com.comprathor.comprathor.entidades.Metadatos;
import com.comprathor.comprathor.entidades.Producto;
import com.comprathor.comprathor.modelos.MetadatosModelo;
import com.comprathor.comprathor.repositorio.MetadatosRepository;
import com.comprathor.comprathor.servicio.CategoriaService;
import com.comprathor.comprathor.servicio.MetadatosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/metadatos", produces = "application/json")
//@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:8888" })
public class MetadatosController{

    @Autowired
    private MetadatosService metadatosService;

    @PostMapping(consumes = "application/json")
    public ResponseEntity<MetadatosModelo> crearMetadato(@RequestBody MetadatosModelo metadatosModelo) {
        MetadatosModelo metadatosnuevo = metadatosService.crearMetadato(metadatosModelo);
        return new ResponseEntity<>(metadatosnuevo, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MetadatosModelo> obtenerMetadatoPorId(@PathVariable Integer id) {
        return metadatosService.obtenerMetadatoPorId(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
    @GetMapping
    public ResponseEntity<List<MetadatosModelo>> obtenerMetadatos() {
        List<MetadatosModelo> metadatos = metadatosService.obtenerMetadatos();
        return new ResponseEntity<>(metadatos, HttpStatus.OK);
    }

    @GetMapping("/categoria/{id}")
    public ResponseEntity<List<MetadatosModelo>> obtenerMetadatosPorCategoria(@PathVariable Integer id) {
        List<MetadatosModelo> metadatos = metadatosService.obtenerMetadatosPorCategoria(id);
        return new ResponseEntity<>(metadatos, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MetadatosModelo> actualizarMetadato(@PathVariable Integer id, @RequestBody MetadatosModelo metadatos) {
        MetadatosModelo metadatoActualizado = metadatosService.actualizarMetadato(id, metadatos);
        return ResponseEntity.ok(metadatoActualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarMetadato(@PathVariable Integer id) {
        metadatosService.eliminarMetadato(id);
        return ResponseEntity.noContent().build();
    }



    }
