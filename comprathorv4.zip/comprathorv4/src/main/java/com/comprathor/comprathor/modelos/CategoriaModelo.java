package com.comprathor.comprathor.modelos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CategoriaModelo {
    private Integer IDCategoria;
    private String Nombre;
    private String Descripcion;
    private String Icono;
    private Integer CantidadProductos;
    public CategoriaModelo(Integer idCategoria) {
        this.IDCategoria = idCategoria;
    }

}
